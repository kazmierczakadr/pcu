#' Konwersja rozmiaru danych
#'
#' @description Funkcja sluzaca do konwersji rozmiaru danych z bajtów 
#' na bity.
#'  
#' @param x wektor zawierajacy wartosc w bajtach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' bajt_to_bit(99)
#' bajt_to_bit(1033)
#' bajt_to_bit(687)
#' bajt_to_bit(c(350, 8332, 11033))


bajt_to_bit = function(x){
  wynik = x * 8
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}





