#' Konwersja odleglosci
#'
#' @description Funkcja sluzaca do konwersji odleglosci
#'   z kilometrow na mile.
#'
#' @param  x zawierajacy wartosc numeryczna w kilometrach
#'   
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' km_to_mil(75)
#' km_to_mil(110)
#' km_to_mil(0)
#' km_to_mil(c(0, 75, 110))



km_to_mil = function(x){
  wynik = x * 1.609
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}


