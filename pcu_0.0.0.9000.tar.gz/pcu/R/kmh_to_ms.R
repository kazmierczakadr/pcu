#' Konwersja predkosci
#'
#' @description Funkcja sluzaca do konwersji kilometrow na godzine 
#'   na mile na sekunde 
#'
#' @param x wektor zawierajacy wartosc predkosci w km/h
#'   
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' kmh_to_ms(75)
#' kmh_to_ms(110)
#' kmh_to_ms(0)
#' kmh_to_ms(c(0, 75, 110))


kmh_to_ms = function(x){
  wynik = x * (1000/3600)
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}


