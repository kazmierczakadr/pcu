#' Konwersja cisnienia
#'
#' @description Funkcja sluzaca do konwersji cisnienia z hektopaskalow
#' na paskale.
#'
#' @param x wektor zawierajacy wartosc cisnienia
#'   w hektopaskalach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' hpa_to_pa(9929)
#' hpa_to_pa(10213)
#' hpa_to_pa(6637)
#' hpa_to_pa(c(503, 8100, 11160))


hpa_to_pa = function(x){
  wynik = x * 100
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}

