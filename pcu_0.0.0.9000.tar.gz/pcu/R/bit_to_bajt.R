#' Konwersja rozmiaru danych
#'
#' @description Funkcja sluzaca do konwersji rozmiaru danych z bitów 
#' na bajty.
#'  
#' @param x wektor zawierajacy wartosc w bitach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' bit_to_bajt(99)
#' bit_to_bajt(1033)
#' bit_to_bajt(687)
#' bit_to_bajt(c(350, 8332, 11033))


bit_to_bajt = function(x){
  wynik = x * 0.125
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}

