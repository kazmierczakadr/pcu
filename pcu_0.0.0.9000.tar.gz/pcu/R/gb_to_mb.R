#' Konwersja rozmiaru danych
#'
#' @description Funkcja sluzaca do konwersji rozmiaru danych z gigabajtów 
#' na megabajty.
#'  
#' @param x wektor zawierajacy wartosc w gigabajtach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' gb_to_mb(99)
#' gb_to_mb(1033)
#' gb_to_mb(687)
#' gb_to_mb(c(350, 8332, 11033))


gb_to_mb = function(x){
  wynik = x * 1024
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}

