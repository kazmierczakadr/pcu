#' Konwersja jednostek masy
#'
#' @description Funkcja sluzaca do konwersji gramów na kilogramy
#'  
#' @param x wektor zawierajacy wartosc w gramach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' g_to_kg(99)
#' g_to_kg(1033)
#' g_to_kg(687)
#' g_to_kg(c(350, 8332, 11033))


g_to_kg = function(x){
  wynik = x * 0.001
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}

