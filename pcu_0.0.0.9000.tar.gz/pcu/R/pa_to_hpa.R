#' Konwersja cisnienia
#'
#' @description Funkcja sluzaca do konwersji cisnienia z paskala
#' na hektopaskale.
#'
#' @param x wektor zawierajacy wartosc cisnienia
#'   w paskalach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' pa_to_hpa(999)
#' pa_to_hpa(1013)
#' pa_to_hpa(667)
#' pa_to_hpa(c(50, 800, 1110))


pa_to_hpa = function(x){
  wynik = x * 0.01
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}

