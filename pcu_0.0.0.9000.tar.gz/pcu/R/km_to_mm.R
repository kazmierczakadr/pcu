#' Konwersja dlugosci
#'
#' @description Funkcja sluzaca do konwersji dlugosci
#'   z kilometra na milimetry
#'
#' @param x wektor zawierajacy wartosc dlugosci
#'   w kilometrach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' km_to_mm(75)
#' km_to_mm(110)
#' km_to_mm(0)
#' km_to_mm(c(0, 75, 110))


km_to_mm = function(x){
  wynik = x * 1000000
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}



