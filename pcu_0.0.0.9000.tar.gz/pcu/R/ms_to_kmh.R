#' Konwersja predkosci
#'
#' @description Funkcja sluzaca do konwersji predkosci 
#'   z metrow na sekunde na kilometry na godzine 
#'
#' @param x wektor zawierajacy wartosc predkosci 
#'   w m/s
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' ms_to_kmh(75)
#' ms_to_kmh(110)
#' ms_to_kmh(0)
#' ms_to_kmh(c(0, 75, 110))


ms_to_kmh = function(x){
  wynik = x *((1/1000)/(1/3600))
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}


