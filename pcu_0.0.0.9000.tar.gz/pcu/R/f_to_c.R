#`Konwersja temperatur
#`
#` @description funckcja sluzaca do konwersji temperatur
#` ze stopni Fahrenheita na Celsjusza
#`
#' @param x wektor zawierajacy wartosci temperatury
#'   w stopniach Fahrenheita
#'
#' @return wartosc numeryczny
#' @export
#'
#' @examples
#' f_to_c(75)
#' f_to_c(110)
#' f_to_c(0)
#' f_to_c(c(0, 75, 110))



f_to_c = function(x){
  wynik = (x-32)*5/9

}


