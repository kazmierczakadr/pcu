#' Konwersja cisnienia
#'
#' @description Funkcja sluzaca do konwersji cisnienia z barów
#' na hektopaskale.
#'
#' @param x wektor zawierajacy wartosc cisnienia
#'   w barach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' bar_to_hpa(99)
#' bar_to_hpa(1033)
#' bar_to_hpa(687)
#' bar_to_hpa(c(350, 8332, 11033))


bar_to_hpa = function(x){
  wynik = x * 1000
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}



