#`Konwersja temperatur
#`
#` @description funckcja sluzaca do konwersji temperatur
#` ze stopni Celsjusza na Fahrenheita
#`
#' @param x wektor zawierajacy wartosci temperatury
#'   w stopniach Celsjusza
#'
#' @return wartosc numeryczny
#' @export
#'
#' @examples
#' cel_to_f(75)
#' cel_to_f(110)
#' cel_to_f(0)
#' cel_to_f(c(0, 75, 110))



c_to_f = function(x){
    wynik = (x*1.8)+32
}


