#' Konwersja temperatury
#'
#' @description Funkcja sluzaca do konwersji temperatury
#'   ze stopni Kelwina na stopnie Fahrenheita
#'
#' @param x wektor zawierajacy wartosc temperatury
#'   w Kelwinach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' k_to_f(75)
#' k_to_f(110)
#' k_to_f(0)
#' k_to_f(c(0, 75, 110))

k_to_f = function(x){
  wynik = (x - 273.15)* 1.8000 + 32.00

  }




