#' Konwersja rozmiaru danych
#'
#' @description Funkcja sluzaca do konwersji rozmiaru danych z megabajtów 
#' na kilobajty.
#'  
#' @param x wektor zawierajacy wartosc w megabajtach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' mb_to_kb(99)
#' mb_to_kb(1033)
#' mb_to_kb(687)
#' mb_to_kb(c(350, 8332, 11033))


mb_to_kb = function(x){
  wynik = x * 1024
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}

