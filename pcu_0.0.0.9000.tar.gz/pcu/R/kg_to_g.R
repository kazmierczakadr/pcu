#' Konwersja jednostek masy
#'
#' @description Funkcja sluzaca do konwersji kilogramów na gramy
#'  
#' @param x wektor zawierajacy wartosc w kilogramach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' kg_to_g(99)
#' kg_to_g(1033)
#' kg_to_g(687)
#' kg_to_g(c(350, 8332, 11033))


kg_to_g = function(x){
  wynik = x * 1000
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}

