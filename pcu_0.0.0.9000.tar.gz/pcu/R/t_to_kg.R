#' Konwersja jednostek masy
#'
#' @description Funkcja sluzaca do konwersji wartosci tony na kilogramy
#'  
#' @param x wektor zawierajacy wartosc w tonach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' t_to_kg(99)
#' t_to_kg(1033)
#' t_to_kg(687)
#' t_to_kg(c(350, 8332, 11033))


t_to_kg = function(x){
  wynik = x * 1000
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}

