#' Konwersja cisnienia
#'
#' @description Funkcja sluzaca do konwersji cisnienia z paskala
#' na bary.
#'
#' @param x wektor zawierajacy wartosc cisnienia
#'   w paskalach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' pa_to_bar(99)
#' pa_to_bar(103)
#' pa_to_bar(67)
#' pa_to_bar(c(50, 80, 110))


pa_to_bar = function(x){
  wynik = x * 0.00001
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}


