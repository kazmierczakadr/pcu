#' Konwersja jednostek masy
#'
#' @description Funkcja sluzaca do konwersji kilogramów na tony
#'  
#' @param x wektor zawierajacy wartosc w kilogramach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' t_to_kg(99)
#' t_to_kg(1033)
#' t_to_kg(687)
#' t_to_kg(c(350, 8332, 11033))


kg_to_kg = function(x){
  wynik = x * 0.001
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}

