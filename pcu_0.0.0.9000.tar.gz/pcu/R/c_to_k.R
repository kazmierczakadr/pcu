#' Konwersja temperatur
#'
#' @description Funkcja sluzaca do konwersji temperatury
#'   ze stopni Celsjusza do stopni Kelwina.
#'
#' @param x wektor zawierajacy wartosci temperatury
#'   w stopniach Celsjusza
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' c_to_k(75)
#' c_to_k(110)
#' c_to_k(0)
#' c_to_k(c(0, 75, 110))


c_to_k = function(x){
  wynik = x + 275.15

}
