#' Konwersja cisnienia
#'
#' @description Funkcja sluzaca do konwersji cisnienia z barów
#' na paskale.
#'
#' @param x wektor zawierajacy wartosc cisnienia
#'   w barach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' bar_to_pa(939)
#' bar_to_pa(10233)
#' bar_to_pa(637)
#' bar_to_pa(c(3350, 820, 110333))


bar_to_pa = function(x){
  wynik = x * 100000
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}



