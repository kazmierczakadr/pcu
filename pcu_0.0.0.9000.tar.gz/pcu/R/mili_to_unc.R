#' Konwersja objętości
#'
#' @description Funkcja sluzaca do konwersji Mililitrów
#'  na Uncje 
#' 
#'  
#' @param x wektor zawierajacy wartosc w mililitrach
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' mili_to_unc(10)
#' mili_to_unc(325)
#' mili_to_unc(6876)
#' mili_to_unc(c(350, 8332, 11033))


mili_to_unc = function(x){
  wynik = x * 0.033814
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}
