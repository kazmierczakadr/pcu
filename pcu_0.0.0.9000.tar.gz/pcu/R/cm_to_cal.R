#' Konwersja dlugosci
#'
#' @description Funkcja sluzaca do konwersji dlugosci
#'   z centymetrow na cale.
#'
#' @param x wektor zawierajacy wartosci centymetra
#'
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' cm_to_c(75)
#' cm_to_c(110)
#' cm_to_c(0)
#' cm_to_c(c(0, 75, 110))


cm_to_c = function(x){
  wynik = x * 2.54
  if (x > 0){
    print(wynik)
  }
  else{
    warning("Coś poszło nie tak sprawdź czy wartość jest numeryczna oraz większa od zera")
  }
}




