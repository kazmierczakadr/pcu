#' Konwersja temperatur
#'
#' @description Funkcja sluzaca do konwersji temperatury
#'   ze stopni Fahrenheita do stopni Kelwina.
#'
#' @param x wektor zawierajacy wartosci temperatury
#'   w stopniach Fahrenheita
#'
#' @return wektor numeryczny
#' @export
#'
#' @examples
#' f_to_k(75)
#' f_to_k(110)
#' f_to_k(0)
#' f_to_k(c(0, 75, 110))


f_to_k = function(x){
  wynik = (x + 459.67)*5/9

}

